# Name: Danison Zhang
# Description: Room Adventure
# Improvements: 1. Added death and win soundfx
#               2. implemented a feature to use items 'use' 
#                  (doesn't do anything, just removes item from inventory)
#               3. Added math mechanic where you can do math to get coins
#                  If you take too long or get it wrong you die


from game import Game

g = Game()
g.run()

